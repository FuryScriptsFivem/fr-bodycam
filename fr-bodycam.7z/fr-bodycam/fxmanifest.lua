fx_version 'cerulean'

games { 'gta5' }

description 'Fury Script BodyCam System V1.0'

version '1.0'

author 'SHOOTYMANE'

ui_page 'index.html'

shared_scripts {
    'config.lua'
}
client_script 'client.lua'
server_scripts {
	'@oxmysql/lib/MySQL.lua',
	'server.lua'
}

files {
	'*.png',
	'*.ttf',
	'*.html',
	'*.css',
	'*.js'
}

lua54 'yes'

-- more info discord : o2_p