



dont forget to create item named body_cam at qb-core/shared/items.lua
    name = 'body_cam',
    label = 'Bodycam',
    weight = 1,
    type = 'item',
    image = 'bcam.png',
    unique = true,
    useable = false,
    shouldClose = false,
    combinable = false,
    description = "It's a bodycam"


add the bodycam image to qb-inventory/html/images 

edit the config file whatever u want

Discord : o2_p
