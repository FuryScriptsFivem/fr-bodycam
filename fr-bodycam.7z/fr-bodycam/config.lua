Config = {}


Config.Core = 'qb'

Config.UseTarget = true --  Enable this if u want to use the target system

---- Locations of the bodycam control center
Config.Locations = {
    { vector3(441.24, -978.85, 30.69) },
    { vector3(447.97, -973.38, 30.69) },
    { vector3(437.03, -996.21, 30.69) },
}

              -- if u are using Config.UseTarget = true then u can edit in these commands if not dont touch them !!
Config.Targets = {
    { coords = vector3(453.16, -987.39, 30.6), width = 1.5, height = 1.5 }, 
    { coords = vector3(447.97, -973.38, 30.69), width = 1.5, height = 1.5 },  
    { coords = vector3(437.03, -996.21, 30.69), width = 1.5, height = 1.5 },
}